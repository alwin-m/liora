import '../home/cycle_algorithm.dart';

class CycleSession {
  static late CycleAlgorithm algorithm;
}
